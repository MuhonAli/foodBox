<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register extends CI_Controller {

	public function index()
	{
		$unique_email = $this->db->select('*')->from('users')->where('email',$this->input->post('email'))->get()->num_rows();
		if ($unique_email>0) {
			$visible = 1;
			$this->session->set_flashdata('visible', $visible);
			$msg='<div class="alert alert-danger">Account exist with this email <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button></div>';
			$this->session->set_flashdata('message',$msg);
			redirect('Welcome');
		}

		$visible = 0;
		$this->session->set_flashdata('visible', $visible);
		$data['email']=$this->input->post('email');
		$data['password']=md5($this->input->post('password'));
		$this->db->insert('users',$data);
		$msg='<div class="alert alert-success">Congratulations! Your Account Created successfully <button type="button" class="close" data-dismiss="alert" aria-label="Close">
		<span aria-hidden="true">&times;</span>
		</button></div>';
		$visible = 1;
		$this->session->set_flashdata('visible', $visible);
		$this->session->set_flashdata('message',$msg);
		redirect('Welcome');
	}


}
